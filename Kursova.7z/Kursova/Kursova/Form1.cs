﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kursova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            string regex = @"[A-Z][A-Z][A-Z]";
            if (!Regex.IsMatch(tb.Text, regex))
            {
                MessageBox.Show("Невалиден триграм!");
                tb.Text = "";
                return;
            }
            
            using (StreamWriter writer = new StreamWriter("INFO.txt", true))
            {

                if (Regex.IsMatch(tb.Text, "MYP"))
                {
                    writer.WriteLine("Марин Петков - 0886850739 (MYP)");
                    MessageBox.Show("Информацията е записана!");
                }
                else if (Regex.IsMatch(tb.Text, "ILG"))
                {
                    writer.WriteLine("Илиян Гласнов - 0886342399 (ILG)");
                    MessageBox.Show("Информацията е записана!");
                }
                else if (Regex.IsMatch(tb.Text, "PYP"))
                {
                    writer.WriteLine("Петко Петков - 0883662983 (PYP)");
                    MessageBox.Show("Информацията е записана!");
                }
                else if (Regex.IsMatch(tb.Text, "GDT"))
                {
                    writer.WriteLine("Георги Димитров - 0888978822 (GDT)");
                    MessageBox.Show("Информацията е записана!");
                }
                else if (Regex.IsMatch(tb.Text, "ISI"))
                {
                    writer.WriteLine("Иван Иванов - 0886345173 (ISI)");
                    MessageBox.Show("Информацията е записана!");
                }
                else
                {
                    MessageBox.Show("Не същестува!");

                }

            }
        
    }
    }
}
